Should work the same as always.

https://github.com/IvanRudyakov/cs4520-assg5-starter-code/tree/main

This was submitted a day late.